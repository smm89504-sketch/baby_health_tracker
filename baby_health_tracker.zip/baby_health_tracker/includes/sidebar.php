<?php
// تأكد من أن هذه المتغيرات (مثل $user_type, $main_dark, $vaccine_alerts) تم تعريفها في الصفحة الرئيسية قبل استدعاء هذا الملف.

// تحديد مسار الملف الحالي واسم الفلتر لتحديد الرابط النشط
$current_page = basename($_SERVER['PHP_SELF']);
$filter_type = $_GET['filter_type'] ?? '';

// تعريف الفئات النشطة بناءً على الصفحة الحالية ونوع المستخدم
$active_class_profile = ($current_page == 'profile.php') ? 'active' : '';
$active_class_children = ($current_page == 'children.php' || $current_page == 'child_details.php' || $current_page == 'edit_child.php' || $current_page == 'child_vaccination.php') ? 'active' : '';
$active_class_archived = ($current_page == 'archived_children.php') ? 'active' : '';
$active_class_daily_activity = ($current_page == 'add_daily_activity.php') ? 'active' : '';
$active_class_vaccine_schedule = ($current_page == 'vaccine_schedule.php') ? 'active' : '';
$active_class_overdue_vaccines = ($current_page == 'overdue_vaccines.php') ? 'active' : '';
$active_class_doctors = ($current_page == 'providers.php' && $filter_type == 'doctor') ? 'active' : '';
$active_class_nurses = ($current_page == 'providers.php' && $filter_type == 'nurse') ? 'active' : '';

// بما أن بعض الصفحات يتم تفعيلها من داخل صفحات أخرى (مثل children.php من child_details.php)
// يجب تعديل الـ active class في الصفحات التي لا تحتوي على الشريط الجانبي بالكامل
// (سنفترض أن children.php هو الأساس لصفحات تفاصيل الأطفال).
?>

<div class="sidebar">
    <a href="<?= $dashboard_link ?>" class="logo">
        <i class="<?= $title_icon ?>"></i>
        <span>لوحة التحكم (<?= $user_type === 'parent' ? 'أهل' : ($user_type === 'doctor' ? 'طبيب' : 'ممرض') ?>)</span>
    </a>
    
    <ul class="nav flex-column">
        <li class="nav-item"><a href="profile.php" class="nav-link <?= $active_class_profile ?>"><i class="fas fa-user"></i><span>الملف الشخصي</span></a></li>
        <li class="nav-item"><a href="children.php" class="nav-link <?= $active_class_children ?>"><i class="fas fa-child"></i><span>إدارة الأطفال</span></a></li>
        
        <?php if ($user_type === 'parent'): ?>
            <li class="nav-item"><a href="archived_children.php" class="nav-link <?= $active_class_archived ?>"><i class="bi bi-archive-fill"></i><span>الأطفال المؤرشفون</span></a></li>
            <li class="nav-item"><a href="add_daily_activity.php" class="nav-link <?= $active_class_daily_activity ?>"><i class="bi bi-journal-plus"></i><span>تسجيل الأنشطة</span></a></li>
        <?php endif; ?>
        
        <?php if ($user_type === 'nurse'): ?>
            <li class="nav-item"><a href="vaccine_schedule.php" class="nav-link <?= $active_class_vaccine_schedule ?>"><i class="bi bi-shield-plus"></i><span>إدارة اللقاحات المعيارية</span></a></li>
            <li class="nav-item"><a href="overdue_vaccines.php" class="nav-link <?= $active_class_overdue_vaccines ?>"><i class="bi bi-calendar-x"></i><span>الأطفال المتأخرون</span></a></li>
        <?php endif; ?>
        
        <li class="nav-item"><a href="providers.php?filter_type=doctor" class="nav-link <?= $active_class_doctors ?>"><i class="fas fa-stethoscope"></i><span>الأطباء</span></a></li>
        <li class="nav-item"><a href="providers.php?filter_type=nurse" class="nav-link <?= $active_class_nurses ?>"><i class="fas fa-user-nurse"></i><span>الممرضون</span></a></li>
    </ul>
    
    <hr class="my-4" style="border-color: rgba(255,255,255,0.2);">
    
    <?php if ($user_type === 'parent'): ?>
    <h6 class="text-white mb-3"><i class="bi bi-bell-fill me-2"></i> إشعارات</h6>
    <?php if (!empty($vaccine_alerts['missed'])): ?>
        <a href="children.php" style="text-decoration: none;">
            <div class="alert alert-missed p-2 mb-2" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> **<?= count($vaccine_alerts['missed']) ?>** تطعيمات فائتة!
            </div>
        </a>
    <?php endif; ?>
    <?php if (!empty($vaccine_alerts['upcoming'])): ?>
        <a href="children.php" style="text-decoration: none;">
            <div class="alert alert-upcoming p-2 mb-2" role="alert">
                <i class="bi bi-clock-fill me-2"></i> **<?= count($vaccine_alerts['upcoming']) ?>** تطعيمات قادمة!
            </div>
        </a>
    <?php endif; ?>
    <?php endif; ?>

    <form method="post" action="logout.php">
        <button type="submit" class="logout-btn mt-4">
            <i class="fas fa-sign-out-alt"></i>
            <span>تسجيل الخروج</span>
        </button>
    </form>
</div>